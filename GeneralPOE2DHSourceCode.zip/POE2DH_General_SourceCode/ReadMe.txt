The codes can be run in MATLAB 2017b on a WINDOWS 7 64 bit platform.

For any questions regarding the codes, please contact Liao Wu via dr.liao.wu@ieee.org